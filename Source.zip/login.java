package yujin;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import com.mysql.cj.xdevapi.Statement;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.awt.event.ActionEvent;
import java.awt.Font;
import java.awt.Color;
import javax.swing.JPasswordField;
import javax.swing.UIManager;

public class login extends JFrame {

	private JPanel contentPane;
	private JTextField user;
	private JLabel lblNewLabel_1;
	private JPasswordField pass;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					login frame = new login();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public login() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 515, 430);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 255, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblUserId = new JLabel("User ID");
		lblUserId.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		lblUserId.setBounds(126, 166, 73, 18);
		contentPane.add(lblUserId);
		
		JLabel lblNewLabel = new JLabel("Password");
		lblNewLabel.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		lblNewLabel.setBounds(126, 218, 73, 18);
		contentPane.add(lblNewLabel);
		
		user = new JTextField();
		user.setBounds(228, 163, 116, 24);
		contentPane.add(user);
		user.setColumns(10);
		
		JButton btnNewButton = new JButton("LOGIN");
		btnNewButton.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		btnNewButton.setForeground(new Color(255, 255, 255));
		btnNewButton.setBackground(new Color(0, 153, 255));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
try {
					
					Class.forName("com.mysql.cj.jdbc.Driver");
					Connection conn= DriverManager.getConnection("jdbc:mysql://localhost:3306/finalproject?useTimezone=true&serverTimezone=UTC","root","admin");
					java.sql.Statement stat=  conn.createStatement();
					String sql="Select *from login where username='" + user.getText() + "' and password='"+pass.getText().toString()+"'";
					ResultSet rs = stat.executeQuery(sql);
					
					if(rs.next()) {
						JOptionPane.showMessageDialog(null, "Login Successfull");
						
						Product frame = new Product();
						frame.table();
						frame.setVisible(true);
						dispose();
						
						
						
					}
					else { 
						JOptionPane.showMessageDialog(null, "Wrong Username and Password");
					conn.close();
					}
					
				}
				catch(Exception e) {
					System.out.println(e);
				 
				
					
				}
				
				
				
				
			}
		});
		btnNewButton.setBounds(176, 289, 131, 43);
		contentPane.add(btnNewButton);
		
		lblNewLabel_1 = new JLabel("Grocery Inventory Management System");
		lblNewLabel_1.setFont(new Font("Microsoft JhengHei UI", Font.BOLD, 20));
		lblNewLabel_1.setBounds(57, 81, 385, 27);
		contentPane.add(lblNewLabel_1);
		
		pass = new JPasswordField();
		pass.setBounds(228, 218, 114, 24);
		contentPane.add(pass);
	}
}
