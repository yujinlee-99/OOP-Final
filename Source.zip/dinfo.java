package yujin;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.Color;
import javax.swing.JScrollPane;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import net.proteanit.sql.DbUtils;

import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import javax.swing.ImageIcon;

public class dinfo extends JFrame {

	private JPanel contentPane;
	private JTable table;

	/**
	 * Launch the application.
	 
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					dinfo frame = new dinfo();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	*/
	/**
	 * Create the frame.
	 */
	
	Connection conn = null;
	PreparedStatement stat = null;
	ResultSet rs = null;
	private JTextField search;
	
	public void table () {
		try {
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/finalproject", "root", "admin");
			String sql = "Select * from delivery";
			stat = conn.prepareStatement(sql);
			rs = stat.executeQuery();
			table.setModel(DbUtils.resultSetToTableModel(rs));
			
		}catch(Exception ex) {
			
			JOptionPane.showMessageDialog(null, ex);
			
		}
	}
	
	public void searchtable () {
		try {
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/finalproject", "root", "admin");
			String sql = "Select * from delivery WHERE Delivery_ID=?";
			stat = conn.prepareStatement(sql);
			stat.setString(1,search.getText());
			rs = stat.executeQuery();
			table.setModel(DbUtils.resultSetToTableModel(rs));
			
		}catch(Exception ex) {
			
			JOptionPane.showMessageDialog(null, ex);
			
		}
	}
	
	public dinfo() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 760, 450);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 255, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton button_1 = new JButton("Products");
		button_1.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Product frame = new Product();
				frame.table();
				frame.setVisible(true);
				dispose();
			}
		});
		button_1.setForeground(Color.WHITE);
		button_1.setBackground(new Color(0, 153, 255));
		button_1.setBounds(0, 58, 148, 51);
		contentPane.add(button_1);
		
		JButton button_2 = new JButton("Customers");
		button_2.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cinfo frame = new cinfo();
				frame.table();
				frame.setVisible(true);
				dispose();
			}
		});
		button_2.setForeground(Color.WHITE);
		button_2.setBackground(new Color(0, 153, 255));
		button_2.setBounds(0, 159, 148, 51);
		contentPane.add(button_2);
		
		JButton button_3 = new JButton("Delivery");
		button_3.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		button_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dinfo frame = new dinfo();
				frame.table();
				frame.setVisible(true);
				dispose();
			}
		});
		button_3.setForeground(Color.WHITE);
		button_3.setBackground(new Color(135, 206, 250));
		button_3.setBounds(0, 259, 148, 51);
		contentPane.add(button_3);
		
		JButton button_4 = new JButton("Supplier");
		button_4.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		button_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				sinfo frame = new sinfo();
				frame.table();
				frame.setVisible(true);
				dispose();
			}
		});
		button_4.setForeground(Color.WHITE);
		button_4.setBackground(new Color(0, 153, 255));
		button_4.setBounds(0, 310, 148, 51);
		contentPane.add(button_4);
		
		JButton button = new JButton("Edit");
		button.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				EditDelivery frame = new EditDelivery();
				frame.setVisible(true);
				dispose();
			}
		});
		button.setBounds(494, 346, 92, 27);
		contentPane.add(button);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(186, 109, 526, 201);
		contentPane.add(scrollPane);
		
		table = new JTable();
		table.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		scrollPane.setViewportView(table);
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Delivery ID", "Destination", "Delivery Description", "Delivery Date"
			}
		));
		table.getColumnModel().getColumn(0).setPreferredWidth(90);
		table.getColumnModel().getColumn(2).setPreferredWidth(166);
		
		JButton btnEmployee = new JButton("Employees");
		btnEmployee.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		btnEmployee.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Employee frame = new Employee();
				frame.table();
				frame.setVisible(true);
				dispose();
			}
		});
		btnEmployee.setForeground(Color.WHITE);
		btnEmployee.setBackground(new Color(0, 153, 255));
		btnEmployee.setBounds(0, 109, 148, 51);
		contentPane.add(btnEmployee);
		
		JButton btnOrders = new JButton("Orders");
		btnOrders.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		btnOrders.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Order frame = new Order();
				frame.table();
				frame.setVisible(true);
				dispose();
			}
		});
		btnOrders.setForeground(Color.WHITE);
		btnOrders.setBackground(new Color(0, 153, 255));
		btnOrders.setBounds(0, 209, 148, 51);
		contentPane.add(btnOrders);
		
		JLabel label = new JLabel("Grocery Inventory Management System");
		label.setFont(new Font("Microsoft JhengHei UI", Font.BOLD, 20));
		label.setBounds(255, 38, 385, 27);
		contentPane.add(label);
		
		JLabel label_1 = new JLabel("ID:");
		label_1.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		label_1.setBounds(200, 350, 24, 18);
		contentPane.add(label_1);
		
		search = new JTextField();
		search.setColumns(10);
		search.setBounds(232, 348, 104, 24);
		contentPane.add(search);
		
		JButton button_5 = new JButton("Search");
		button_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				searchtable();
			}
		});
		button_5.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		button_5.setBounds(345, 346, 93, 27);
		contentPane.add(button_5);
		
		JLabel label_2 = new JLabel("Back");
		label_2.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		label_2.setBounds(629, 350, 32, 18);
		contentPane.add(label_2);
		
		JButton button_6 = new JButton("");
		button_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				table();
			}
		});
		button_6.setIcon(new ImageIcon("C:\\Users\\Owner1\\Downloads\\iconfinder_basics-01_296833 (2).png"));
		button_6.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		button_6.setBounds(667, 346, 30, 27);
		contentPane.add(button_6);
	}

}
