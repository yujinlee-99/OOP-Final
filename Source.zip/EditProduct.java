package yujin;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.HeadlessException;

import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;

public class EditProduct extends JFrame {

	private JPanel contentPane;
	private JTextField productID;
	private JTextField ProductName;
	private JTextField ProductPrice;
	private JTextField ProductQuantity;
	private JTextField ExpirationDate;
	private JTextField ProductID;

	Connection conn = null;
	PreparedStatement stat = null;
	ResultSet rs = null;
	private JTextField supid;
	private JTextField orderid;
	
	/**
	 * Launch the application.
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					EditProduct frame = new EditProduct();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	*/
	/**
	 * Create the frame.
	 */
	public EditProduct() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 760, 450);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 255, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnCustomers = new JButton("Customers");
		btnCustomers.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		btnCustomers.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				cinfo frame = new cinfo();
				frame.table();
				frame.setVisible(true);
				dispose();
			}
		});
		btnCustomers.setForeground(Color.WHITE);
		btnCustomers.setBackground(new Color(0, 153, 255));
		btnCustomers.setBounds(0, 148, 148, 51);
		contentPane.add(btnCustomers);
		
		JButton btnDelivery = new JButton("Delivery");
		btnDelivery.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		btnDelivery.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				dinfo frame = new dinfo();
				frame.table();
				frame.setVisible(true);
				dispose();
			}
		});
		btnDelivery.setForeground(Color.WHITE);
		btnDelivery.setBackground(new Color(0, 153, 255));
		btnDelivery.setBounds(0, 250, 148, 51);
		contentPane.add(btnDelivery);
		
		JButton btnSupplier = new JButton("Supplier");
		btnSupplier.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		btnSupplier.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				sinfo frame = new sinfo();
				frame.table();
				frame.setVisible(true);
				dispose();
			}
		});
		btnSupplier.setForeground(Color.WHITE);
		btnSupplier.setBackground(new Color(0, 153, 255));
		btnSupplier.setBounds(0, 301, 148, 51);
		contentPane.add(btnSupplier);
		
		JButton btnAdd = new JButton("Add");
		btnAdd.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		btnAdd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

					try {
					
					String sql = "Insert into product" + "(Product_ID, Product_Name, Product_Price, Product_Quantity, Product_ExDate, Supplier_ID, Order_ID)" + "values (?,?,?,?,?,?,?)";
					conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/finalproject?useTimezone=true&serverTimezone=UTC", "root", "admin");
					stat = conn.prepareStatement(sql);
					stat.setString(1, productID.getText());
					stat.setString(2, ProductName.getText());
					stat.setString(3, ProductPrice.getText());
					stat.setString(4, ProductQuantity.getText());
					stat.setString(5, ExpirationDate.getText());
					stat.setString(6, supid.getText());
					stat.setString(6, orderid.getText());
					stat.executeUpdate();
					JOptionPane.showMessageDialog(null, "Product Added");
					Product Frame1 = new Product();
					Frame1.table();
					Frame1.setVisible(true);
					
					dispose();
					
					
				} 
					
					catch(SQLException | HeadlessException ex) {
					JOptionPane.showMessageDialog(null, ex);
				}

					
			}
		});
		btnAdd.setBounds(591, 251, 115, 27);
		contentPane.add(btnAdd);
		
		JButton btnDelete = new JButton("Delete");
		btnDelete.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				try {
					String sql = "Delete from product where Product_ID =?";
				conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/finalproject","root","admin");
					stat = conn.prepareStatement(sql);
					stat.setString(1,ProductID.getText());
					stat.executeUpdate();
					
				
				JOptionPane.showMessageDialog(null, "Product Deleted");
				
				}
				catch(SQLException	| HeadlessException ex) {
				
					JOptionPane.showMessageDialog(null, ex);
			
				}

				Product Frame1 = new Product();	
				Frame1.table();
				Frame1.setVisible(true);
				
				dispose();
			}
		});
		btnDelete.setBounds(456, 330, 115, 27);
		contentPane.add(btnDelete);
		
		JLabel lblNewLabel = new JLabel("Product Name");
		lblNewLabel.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		lblNewLabel.setBounds(188, 181, 122, 18);
		contentPane.add(lblNewLabel);
		
		productID = new JTextField();
		productID.setBounds(324, 140, 116, 24);
		contentPane.add(productID);
		productID.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("Product ID");
		lblNewLabel_1.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		lblNewLabel_1.setBounds(188, 142, 87, 18);
		contentPane.add(lblNewLabel_1);
		
		ProductName = new JTextField();
		ProductName.setColumns(10);
		ProductName.setBounds(324, 179, 116, 24);
		contentPane.add(ProductName);
		
		JLabel lblNewLabel_2 = new JLabel("Product Quantity");
		lblNewLabel_2.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		lblNewLabel_2.setBounds(188, 255, 133, 18);
		contentPane.add(lblNewLabel_2);
		
		ProductPrice = new JTextField();
		ProductPrice.setColumns(10);
		ProductPrice.setBounds(324, 216, 116, 24);
		contentPane.add(ProductPrice);
		
		JLabel lblNewLabel_3 = new JLabel("Product Price");
		lblNewLabel_3.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		lblNewLabel_3.setBounds(188, 219, 98, 18);
		contentPane.add(lblNewLabel_3);
		
		ProductQuantity = new JTextField();
		ProductQuantity.setColumns(10);
		ProductQuantity.setBounds(324, 252, 116, 24);
		contentPane.add(ProductQuantity);
		
		JLabel lblNewLabel_4 = new JLabel("Expiration Date");
		lblNewLabel_4.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		lblNewLabel_4.setBounds(454, 143, 105, 18);
		contentPane.add(lblNewLabel_4);
		
		ExpirationDate = new JTextField();
		ExpirationDate.setColumns(10);
		ExpirationDate.setBounds(590, 140, 116, 24);
		contentPane.add(ExpirationDate);
		
		JLabel label_1 = new JLabel("Product ID");
		label_1.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		label_1.setBounds(188, 334, 87, 18);
		contentPane.add(label_1);
		
		ProductID = new JTextField();
		ProductID.setColumns(10);
		ProductID.setBounds(324, 332, 116, 24);
		contentPane.add(ProductID);
		
		JButton btnProducts = new JButton("Products");
		btnProducts.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		btnProducts.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Product frame = new Product();
				frame.table();
				frame.setVisible(true);
				dispose();
			}
		});
		btnProducts.setForeground(Color.WHITE);
		btnProducts.setBackground(new Color(135, 206, 250));
		btnProducts.setBounds(0, 46, 148, 51);
		contentPane.add(btnProducts);
		
		JButton btnEmployee = new JButton("Employees");
		btnEmployee.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		btnEmployee.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Employee frame = new Employee();
				frame.table();
				frame.setVisible(true);
				dispose();
			}
		});
		btnEmployee.setForeground(Color.WHITE);
		btnEmployee.setBackground(new Color(0, 153, 255));
		btnEmployee.setBounds(0, 97, 148, 51);
		contentPane.add(btnEmployee);
		
		JButton btnOrders = new JButton("Orders");
		btnOrders.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		btnOrders.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Order frame = new Order();
				frame.table();
				frame.setVisible(true);
				dispose();
			}
		});
		btnOrders.setForeground(Color.WHITE);
		btnOrders.setBackground(new Color(0, 153, 255));
		btnOrders.setBounds(0, 199, 148, 51);
		contentPane.add(btnOrders);
		
		JLabel lblNewLabel_5 = new JLabel("Supplier ID");
		lblNewLabel_5.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		lblNewLabel_5.setBounds(456, 182, 96, 18);
		contentPane.add(lblNewLabel_5);
		
		supid = new JTextField();
		supid.setBounds(590, 179, 116, 24);
		contentPane.add(supid);
		supid.setColumns(10);
		
		JLabel label = new JLabel("Grocery Inventory Management System");
		label.setFont(new Font("Microsoft JhengHei UI", Font.BOLD, 20));
		label.setBounds(240, 27, 385, 27);
		contentPane.add(label);
		
		JButton button = new JButton("");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Product frame = new Product();
				frame.table();
				frame.setVisible(true);
				dispose();
			}
		});
		button.setIcon(new ImageIcon("C:\\Users\\Owner1\\Downloads\\iconfinder_basics-01_296833 (2).png"));
		button.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		button.setBounds(674, 330, 30, 27);
		contentPane.add(button);
		
		JLabel label_2 = new JLabel("Back");
		label_2.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		label_2.setBounds(630, 334, 40, 18);
		contentPane.add(label_2);
		
		JLabel lblNewLabel_6 = new JLabel("Order ID");
		lblNewLabel_6.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		lblNewLabel_6.setBounds(456, 219, 62, 18);
		contentPane.add(lblNewLabel_6);
		
		orderid = new JTextField();
		orderid.setText("");
		orderid.setBounds(590, 215, 116, 24);
		contentPane.add(orderid);
		orderid.setColumns(10);
	}
}
