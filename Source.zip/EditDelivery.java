package yujin;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.HeadlessException;

import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;

public class EditDelivery extends JFrame {

	private JPanel contentPane;
	private JTextField deliveryID;

	Connection conn = null;
	PreparedStatement stat = null;
	ResultSet rs = null;
	private JTextField dd;
	private JTextField orid;
	private JTextField empid;
	private JTextField DeliveryID;
	
	/**
	 * Launch the application.
	 
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					EditDelivery frame = new EditDelivery();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	*/
	/**
	 * Create the frame.
	 */
	public EditDelivery() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 760, 450);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton button = new JButton("Products");
		button.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
					Product frame = new Product();
					frame.table();
					frame.setVisible(true);
					dispose();
			}
		});
		button.setForeground(Color.WHITE);
		button.setBackground(new Color(0, 153, 255));
		button.setBounds(0, 61, 148, 51);
		contentPane.add(button);
		
		JButton button_1 = new JButton("Customers");
		button_1.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cinfo frame = new cinfo();
				frame.table();
				frame.setVisible(true);
				dispose();
			}
		});
		button_1.setForeground(Color.WHITE);
		button_1.setBackground(new Color(0, 153, 255));
		button_1.setBounds(0, 163, 148, 51);
		contentPane.add(button_1);
		
		JButton button_2 = new JButton("Delivery");
		button_2.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dinfo frame = new dinfo();
				frame.table();
				frame.setVisible(true);
				dispose();
			}
		});
		button_2.setForeground(Color.WHITE);
		button_2.setBackground(new Color(135, 206, 250));
		button_2.setBounds(0, 264, 148, 51);
		contentPane.add(button_2);
		
		JButton button_3 = new JButton("Supplier");
		button_3.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		button_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				sinfo frame = new sinfo();
				frame.table();
				frame.setVisible(true);
				dispose();
			}
		});
		button_3.setForeground(Color.WHITE);
		button_3.setBackground(new Color(0, 153, 255));
		button_3.setBounds(0, 315, 148, 51);
		contentPane.add(button_3);
		
		JLabel lblDeliveryId = new JLabel("Delivery ID");
		lblDeliveryId.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		lblDeliveryId.setBounds(192, 130, 89, 18);
		contentPane.add(lblDeliveryId);
		
		deliveryID = new JTextField();
		deliveryID.setColumns(10);
		deliveryID.setBounds(337, 127, 116, 24);
		contentPane.add(deliveryID);
		
		JButton button_4 = new JButton("Add");
		button_4.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		button_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try {
					
					String sql = "Insert into delivery" + "(Delivery_ID, Delivery_Date, Order_ID, Employee_ID)" + "values (?,?,?,?)";
					conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/finalproject?useTimezone=true&serverTimezone=UTC", "root", "admin");
					stat = conn.prepareStatement(sql);
					stat.setString(1, deliveryID.getText());
					stat.setString(2, dd.getText());
					stat.setString(3, orid.getText());
					stat.setString(4, empid.getText());
					stat.executeUpdate();
					JOptionPane.showMessageDialog(null, "Delivery info Added");
					dinfo Frame1 = new dinfo();
					Frame1.table();
					Frame1.setVisible(true);
					
					dispose();
					
					
				} 
					
					catch(SQLException | HeadlessException ex) {
					JOptionPane.showMessageDialog(null, ex);
				}
				
			}
		});
		button_4.setBounds(491, 228, 115, 27);
		contentPane.add(button_4);
		
		JButton button_5 = new JButton("Delete");
		button_5.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		button_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				try {
					String sql = "Delete from delivery where Delivery_ID =?";
				conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/finalproject","root","admin");
					stat = conn.prepareStatement(sql);
					stat.setString(1,DeliveryID.getText());
					stat.executeUpdate();
					
				
				JOptionPane.showMessageDialog(null, "Delivery info Deleted");
				
				}
				catch(SQLException	| HeadlessException ex) {
				
					JOptionPane.showMessageDialog(null, ex);
			
				}

				dinfo Frame1 = new dinfo();	
				Frame1.table();
				Frame1.setVisible(true);
				
				dispose();
				
			}
		});
		button_5.setBounds(491, 323, 115, 27);
		contentPane.add(button_5);
		
		JLabel lblNewLabel = new JLabel("Delivery Date");
		lblNewLabel.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		lblNewLabel.setBounds(192, 163, 107, 18);
		contentPane.add(lblNewLabel);
		
		dd = new JTextField();
		dd.setBounds(337, 160, 116, 24);
		contentPane.add(dd);
		dd.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("Order ID");
		lblNewLabel_1.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		lblNewLabel_1.setBounds(192, 197, 138, 18);
		contentPane.add(lblNewLabel_1);
		
		orid = new JTextField();
		orid.setBounds(337, 194, 116, 24);
		contentPane.add(orid);
		orid.setColumns(10);
		
		JLabel lblNewLabel_2 = new JLabel("Employee ID");
		lblNewLabel_2.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		lblNewLabel_2.setBounds(192, 232, 89, 18);
		contentPane.add(lblNewLabel_2);
		
		empid = new JTextField();
		empid.setBounds(337, 229, 116, 24);
		contentPane.add(empid);
		empid.setColumns(10);
		
		JLabel label_1 = new JLabel("Delivery ID");
		label_1.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		label_1.setBounds(192, 327, 89, 18);
		contentPane.add(label_1);
		
		DeliveryID = new JTextField();
		DeliveryID.setColumns(10);
		DeliveryID.setBounds(337, 324, 116, 24);
		contentPane.add(DeliveryID);
		
		JButton btnEmployees = new JButton("Employees");
		btnEmployees.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		btnEmployees.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Employee frame = new Employee();
				frame.table();
				frame.setVisible(true);
				dispose();
			}
		});
		btnEmployees.setForeground(Color.WHITE);
		btnEmployees.setBackground(new Color(0, 153, 255));
		btnEmployees.setBounds(0, 112, 148, 51);
		contentPane.add(btnEmployees);
		
		JButton btnOrders = new JButton("Orders");
		btnOrders.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		btnOrders.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Order frame = new Order();
				frame.table();
				frame.setVisible(true);
				dispose();
			}
		});
		btnOrders.setForeground(Color.WHITE);
		btnOrders.setBackground(new Color(0, 153, 255));
		btnOrders.setBounds(0, 214, 148, 51);
		contentPane.add(btnOrders);
		
		JLabel label = new JLabel("Grocery Inventory Management System");
		label.setFont(new Font("Microsoft JhengHei UI", Font.BOLD, 20));
		label.setBounds(248, 45, 385, 27);
		contentPane.add(label);
		
		JLabel label_2 = new JLabel("Back");
		label_2.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		label_2.setBounds(627, 332, 40, 18);
		contentPane.add(label_2);
		
		JButton button_6 = new JButton("");
		button_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dinfo frame = new dinfo();
				frame.table();
				frame.setVisible(true);
				dispose();
			}
		});
		button_6.setIcon(new ImageIcon("C:\\Users\\Owner1\\Downloads\\iconfinder_basics-01_296833 (2).png"));
		button_6.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		button_6.setBounds(671, 328, 30, 27);
		contentPane.add(button_6);
	}

}
