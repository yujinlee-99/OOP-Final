package yujin;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.Color;
import javax.swing.JScrollPane;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import net.proteanit.sql.DbUtils;

import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import javax.swing.ImageIcon;

public class sinfo extends JFrame {

	private JPanel contentPane;
	private JTable table;

	/**
	 * Launch the application.
	 
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					sinfo frame = new sinfo();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	*/
	/**
	 * Create the frame.
	 */
	
	Connection conn = null;
	PreparedStatement stat = null;
	ResultSet rs = null;
	private JTextField search;
	
	public void table () {
		try {
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/finalproject", "root", "admin");
			String sql = "Select * from supplier";
			stat = conn.prepareStatement(sql);
			rs = stat.executeQuery();
			table.setModel(DbUtils.resultSetToTableModel(rs));
			
		}catch(Exception ex) {
			
			JOptionPane.showMessageDialog(null, ex);
			
		}
	}
	
	public void searchtable () {
		try {
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/finalproject", "root", "admin");
			String sql = "Select * from supplier WHERE Supplier_ID=?";
			stat = conn.prepareStatement(sql);
			stat.setString(1,search.getText());
			rs = stat.executeQuery();
			table.setModel(DbUtils.resultSetToTableModel(rs));
			
		}catch(Exception ex) {
			
			JOptionPane.showMessageDialog(null, ex);
			
		}
	}
	
	public sinfo() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 760, 450);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 255, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton button_1 = new JButton("Products");
		button_1.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Product frame = new Product();
				frame.table();
				frame.setVisible(true);
				dispose();
			}
		});
		button_1.setForeground(Color.WHITE);
		button_1.setBackground(new Color(0, 153, 255));
		button_1.setBounds(0, 53, 148, 51);
		contentPane.add(button_1);
		
		JButton button_2 = new JButton("Customers");
		button_2.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cinfo frame = new cinfo();
				frame.table();
				frame.setVisible(true);
				dispose();
			}
		});
		button_2.setForeground(Color.WHITE);
		button_2.setBackground(new Color(0, 153, 255));
		button_2.setBounds(0, 155, 148, 51);
		contentPane.add(button_2);
		
		JButton button_3 = new JButton("Delivery");
		button_3.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		button_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dinfo frame = new dinfo();
				frame.table();
				frame.setVisible(true);
				dispose();
			}
		});
		button_3.setForeground(Color.WHITE);
		button_3.setBackground(new Color(0, 153, 255));
		button_3.setBounds(0, 257, 148, 51);
		contentPane.add(button_3);
		
		JButton button_4 = new JButton("Supplier");
		button_4.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		button_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				sinfo frame = new sinfo();
				frame.table();
				frame.setVisible(true);
				dispose();
			}
		});
		button_4.setForeground(Color.WHITE);
		button_4.setBackground(new Color(135, 206, 250));
		button_4.setBounds(0, 308, 148, 51);
		contentPane.add(button_4);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(183, 103, 527, 205);
		contentPane.add(scrollPane);
		
		table = new JTable();
		table.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		scrollPane.setViewportView(table);
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Supplier ID", "Supplier Name", "Contact Number"
			}
		));
		
		JButton button = new JButton("Edit");
		button.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				EditSupplier frame = new EditSupplier();
				frame.setVisible(true);
				dispose();
			}
		});
		button.setBounds(499, 345, 92, 27);
		contentPane.add(button);
		
		JButton btnEmployees = new JButton("Employees");
		btnEmployees.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		btnEmployees.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Employee frame = new Employee();
				frame.table();
				frame.setVisible(true);
				dispose();
			}
		});
		btnEmployees.setForeground(Color.WHITE);
		btnEmployees.setBackground(new Color(0, 153, 255));
		btnEmployees.setBounds(0, 104, 148, 51);
		contentPane.add(btnEmployees);
		
		JButton btnOrders = new JButton("Orders");
		btnOrders.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		btnOrders.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Order frame = new Order();
				frame.table();
				frame.setVisible(true);
				dispose();
			}
		});
		btnOrders.setForeground(Color.WHITE);
		btnOrders.setBackground(new Color(0, 153, 255));
		btnOrders.setBounds(0, 206, 148, 51);
		contentPane.add(btnOrders);
		
		JLabel label = new JLabel("Grocery Inventory Management System");
		label.setFont(new Font("Microsoft JhengHei UI", Font.BOLD, 20));
		label.setBounds(247, 40, 385, 27);
		contentPane.add(label);
		
		JLabel label_1 = new JLabel("ID:");
		label_1.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		label_1.setBounds(202, 349, 24, 18);
		contentPane.add(label_1);
		
		search = new JTextField();
		search.setColumns(10);
		search.setBounds(234, 347, 104, 24);
		contentPane.add(search);
		
		JButton button_5 = new JButton("Search");
		button_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				searchtable();
			}
		});
		button_5.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		button_5.setBounds(347, 345, 93, 27);
		contentPane.add(button_5);
		
		JLabel label_2 = new JLabel("Back");
		label_2.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		label_2.setBounds(631, 349, 32, 18);
		contentPane.add(label_2);
		
		JButton button_6 = new JButton("");
		button_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				table();
			}
		});
		button_6.setIcon(new ImageIcon("C:\\Users\\Owner1\\Downloads\\iconfinder_basics-01_296833 (2).png"));
		button_6.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		button_6.setBounds(669, 345, 30, 27);
		contentPane.add(button_6);
		table.getColumnModel().getColumn(0).setPreferredWidth(99);
		table.getColumnModel().getColumn(1).setPreferredWidth(110);
		table.getColumnModel().getColumn(2).setPreferredWidth(128);
	}

}
