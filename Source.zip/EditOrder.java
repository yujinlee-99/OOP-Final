package yujin;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.HeadlessException;

import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;

public class EditOrder extends JFrame {

	private JPanel contentPane;
	private JTextField orderID;
	private JTextField OrD;
	private JTextField Quan;
	private JTextField TotalP;
	private JTextField CusID;
	private JTextField OrderID;
	
	Connection conn = null;
	PreparedStatement stat = null;
	ResultSet rs = null;
	private JTextField deliveryid;
	
	/**
	 * Launch the application.
	 
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					EditOrder frame = new EditOrder();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	*/
	/**
	 * Create the frame.
	 */
	public EditOrder() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 760, 450);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 255, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton button = new JButton("Products");
		button.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Product frame = new Product();
				frame.table();
				frame.setVisible(true);
				dispose();
			}
		});
		button.setForeground(Color.WHITE);
		button.setBackground(new Color(0, 153, 255));
		button.setBounds(0, 50, 148, 51);
		contentPane.add(button);
		
		JButton button_1 = new JButton("Employees");
		button_1.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Employee frame = new Employee();
				frame.table();
				frame.setVisible(true);
				dispose();
			}
		});
		button_1.setForeground(Color.WHITE);
		button_1.setBackground(new Color(0, 153, 255));
		button_1.setBounds(0, 98, 148, 51);
		contentPane.add(button_1);
		
		JButton button_2 = new JButton("Customers");
		button_2.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cinfo frame = new cinfo();
				frame.table();
				frame.setVisible(true);
				dispose();
			}
		});
		button_2.setForeground(Color.WHITE);
		button_2.setBackground(new Color(0, 153, 255));
		button_2.setBounds(0, 149, 148, 51);
		contentPane.add(button_2);
		
		JButton button_3 = new JButton("Orders");
		button_3.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		button_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Order frame = new Order();
				frame.table();
				frame.setVisible(true);
				dispose();
			}
		});
		button_3.setForeground(Color.WHITE);
		button_3.setBackground(new Color(135, 206, 250));
		button_3.setBounds(0, 200, 148, 51);
		contentPane.add(button_3);
		
		JButton button_4 = new JButton("Delivery");
		button_4.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		button_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dinfo frame = new dinfo();
				frame.table();
				frame.setVisible(true);
				dispose();
			}
		});
		button_4.setForeground(Color.WHITE);
		button_4.setBackground(new Color(0, 153, 255));
		button_4.setBounds(0, 251, 148, 51);
		contentPane.add(button_4);
		
		JButton button_5 = new JButton("Supplier");
		button_5.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		button_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				sinfo frame = new sinfo();
				frame.table();
				frame.setVisible(true);
				dispose();
			}
		});
		button_5.setForeground(Color.WHITE);
		button_5.setBackground(new Color(0, 153, 255));
		button_5.setBounds(0, 302, 148, 51);
		contentPane.add(button_5);
		
		JLabel lblNewLabel = new JLabel("Order ID");
		lblNewLabel.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		lblNewLabel.setBounds(217, 114, 62, 18);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Order Date");
		lblNewLabel_1.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		lblNewLabel_1.setBounds(217, 149, 90, 18);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_3 = new JLabel("Quantity");
		lblNewLabel_3.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		lblNewLabel_3.setBounds(217, 185, 62, 18);
		contentPane.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("Total Price");
		lblNewLabel_4.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		lblNewLabel_4.setBounds(217, 220, 78, 18);
		contentPane.add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("Customer ID");
		lblNewLabel_5.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		lblNewLabel_5.setBounds(217, 253, 102, 18);
		contentPane.add(lblNewLabel_5);
		
		orderID = new JTextField();
		orderID.setBounds(345, 111, 116, 24);
		contentPane.add(orderID);
		orderID.setColumns(10);
		
		OrD = new JTextField();
		OrD.setBounds(345, 146, 116, 24);
		contentPane.add(OrD);
		OrD.setColumns(10);
		
		Quan = new JTextField();
		Quan.setBounds(345, 182, 116, 24);
		contentPane.add(Quan);
		Quan.setColumns(10);
		
		TotalP = new JTextField();
		TotalP.setBounds(345, 217, 116, 24);
		contentPane.add(TotalP);
		TotalP.setColumns(10);
		
		CusID = new JTextField();
		CusID.setBounds(345, 250, 116, 24);
		contentPane.add(CusID);
		CusID.setColumns(10);
		
		JButton btnNewButton = new JButton("Add");
		btnNewButton.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try {
					
					String sql = "Insert into orders" + "(Order_ID, Order_Date, Quantity, TotalPrice, Customer_ID, Delivery_ID)" + "values (?,?,?,?,?,?)";
					conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/finalproject?useTimezone=true&serverTimezone=UTC", "root", "admin");
					stat = conn.prepareStatement(sql);
					stat.setString(1, orderID.getText());
					stat.setString(2, OrD.getText());
					stat.setString(3, Quan.getText());
					stat.setString(4, TotalP.getText());
					stat.setString(5, CusID.getText());
					stat.setString(6, deliveryid.getText());
					stat.executeUpdate();
					JOptionPane.showMessageDialog(null, "Order info Added");
					Order Frame1 = new Order();
					Frame1.table();
					Frame1.setVisible(true);
					
					dispose();
					
					
				} 
					
					catch(SQLException | HeadlessException ex) {
					JOptionPane.showMessageDialog(null, ex);
				}

				
			}
		});
		btnNewButton.setBounds(495, 280, 105, 27);
		contentPane.add(btnNewButton);
		
		JLabel label_1 = new JLabel("Order ID");
		label_1.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		label_1.setBounds(217, 354, 62, 18);
		contentPane.add(label_1);
		
		OrderID = new JTextField();
		OrderID.setBounds(345, 351, 116, 24);
		contentPane.add(OrderID);
		OrderID.setColumns(10);
		
		JButton btnNewButton_1 = new JButton("Delete");
		btnNewButton_1.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					String sql = "Delete from orders where Order_ID =?";
					conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/finalproject","root","admin");
					stat = conn.prepareStatement(sql);
					stat.setString(1,OrderID.getText());
					stat.executeUpdate();
					
				
				JOptionPane.showMessageDialog(null, "Order Deleted");
				
				}
				catch(SQLException	| HeadlessException ex) {
				
					JOptionPane.showMessageDialog(null, ex);
			
				}

				Order Frame1 = new Order();	
				Frame1.table();
				Frame1.setVisible(true);
				
				dispose();
			}
		});
		btnNewButton_1.setBounds(495, 350, 105, 27);
		contentPane.add(btnNewButton_1);
		
		JLabel label = new JLabel("Grocery Inventory Management System");
		label.setFont(new Font("Microsoft JhengHei UI", Font.BOLD, 20));
		label.setBounds(245, 43, 385, 27);
		contentPane.add(label);
		
		JLabel label_2 = new JLabel("Back");
		label_2.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		label_2.setBounds(635, 358, 40, 18);
		contentPane.add(label_2);
		
		JButton button_6 = new JButton("");
		button_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Order frame = new Order();
				frame.table();
				frame.setVisible(true);
				dispose();
			}
		});
		button_6.setIcon(new ImageIcon("C:\\Users\\Owner1\\Downloads\\iconfinder_basics-01_296833 (2).png"));
		button_6.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		button_6.setBounds(679, 354, 30, 27);
		contentPane.add(button_6);
		
		JLabel lblNewLabel_2 = new JLabel("Delivery ID");
		lblNewLabel_2.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		lblNewLabel_2.setBounds(217, 289, 90, 18);
		contentPane.add(lblNewLabel_2);
		
		deliveryid = new JTextField();
		deliveryid.setBounds(345, 283, 116, 24);
		contentPane.add(deliveryid);
		deliveryid.setColumns(10);
	}
}
