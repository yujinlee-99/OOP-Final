package yujin;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.HeadlessException;

import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;

public class EditCustomer extends JFrame {

	private JPanel contentPane;
	private JTextField customerID;
	private JTextField CustomerName;
	private JTextField CContactNumber;
	private JTextField CustomerAddress;
	private JTextField CustomerID;

	Connection conn = null;
	PreparedStatement stat = null;
	ResultSet rs = null;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					EditCustomer frame = new EditCustomer();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public EditCustomer() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 760, 450);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 255, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton button = new JButton("Products");
		button.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Product frame = new Product();
				frame.table();
				frame.setVisible(true);
				dispose();
			}
		});
		button.setForeground(Color.WHITE);
		button.setBackground(new Color(0, 153, 255));
		button.setBounds(0, 51, 148, 51);
		contentPane.add(button);
		
		JButton button_1 = new JButton("Customers");
		button_1.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cinfo frame = new cinfo();
				frame.table();
				frame.setVisible(true);
				dispose();
			}
		});
		button_1.setForeground(Color.WHITE);
		button_1.setBackground(new Color(135, 206, 250));
		button_1.setBounds(0, 150, 148, 51);
		contentPane.add(button_1);
		
		JButton button_2 = new JButton("Delivery");
		button_2.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dinfo frame = new dinfo();
				frame.table();
				frame.setVisible(true);
				dispose();
			}
		});
		button_2.setForeground(Color.WHITE);
		button_2.setBackground(new Color(0, 153, 255));
		button_2.setBounds(0, 252, 148, 51);
		contentPane.add(button_2);
		
		JButton button_3 = new JButton("Supplier");
		button_3.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		button_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				sinfo frame = new sinfo();
				frame.table();
				frame.setVisible(true);
				dispose();
			}
		});
		button_3.setForeground(Color.WHITE);
		button_3.setBackground(new Color(0, 153, 255));
		button_3.setBounds(0, 303, 148, 51);
		contentPane.add(button_3);
		
		JLabel lblCustomerId = new JLabel("Customer ID");
		lblCustomerId.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		lblCustomerId.setBounds(196, 112, 116, 18);
		contentPane.add(lblCustomerId);
		
		JLabel lblCustomerName = new JLabel("Customer Name");
		lblCustomerName.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		lblCustomerName.setBounds(196, 159, 116, 18);
		contentPane.add(lblCustomerName);
		
		JLabel lblContactNumber = new JLabel("Contact Number");
		lblContactNumber.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		lblContactNumber.setBounds(196, 206, 116, 18);
		contentPane.add(lblContactNumber);
		
		JLabel lblAddress = new JLabel("Address");
		lblAddress.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		lblAddress.setBounds(196, 251, 116, 18);
		contentPane.add(lblAddress);
		
		customerID = new JTextField();
		customerID.setBounds(346, 109, 116, 24);
		contentPane.add(customerID);
		customerID.setColumns(10);
		
		CustomerName = new JTextField();
		CustomerName.setColumns(10);
		CustomerName.setBounds(346, 157, 116, 24);
		contentPane.add(CustomerName);
		
		CContactNumber = new JTextField();
		CContactNumber.setColumns(10);
		CContactNumber.setBounds(346, 204, 116, 24);
		contentPane.add(CContactNumber);
		
		CustomerAddress = new JTextField();
		CustomerAddress.setColumns(10);
		CustomerAddress.setBounds(346, 249, 116, 24);
		contentPane.add(CustomerAddress);
		
		JButton button_4 = new JButton("Add");
		button_4.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		button_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				try {
					
					String sql = "Insert into customer" + "(Customer_ID, Customer_Name, Customer_CN, Customer_Address)" + "values (?,?,?,?)";
					conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/finalproject?useTimezone=true&serverTimezone=UTC", "root", "admin");
					stat = conn.prepareStatement(sql);
					stat.setString(1, customerID.getText());
					stat.setString(2, CustomerName.getText());
					stat.setString(3, CContactNumber.getText());
					stat.setString(4, CustomerAddress.getText());

					stat.executeUpdate();
					JOptionPane.showMessageDialog(null, "Customer info Added");
					cinfo Frame1 = new cinfo();
					Frame1.table();
					Frame1.setVisible(true);
					
					dispose();
					
					
				} 
					
					catch(SQLException | HeadlessException ex) {
					JOptionPane.showMessageDialog(null, ex);
				}

				
			}
		});
		button_4.setBounds(476, 247, 115, 27);
		contentPane.add(button_4);
		
		JLabel label_1 = new JLabel("Customer ID");
		label_1.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		label_1.setBounds(196, 340, 116, 18);
		contentPane.add(label_1);
		
		CustomerID = new JTextField();
		CustomerID.setColumns(10);
		CustomerID.setBounds(346, 337, 116, 24);
		contentPane.add(CustomerID);
		
		JButton button_5 = new JButton("Delete");
		button_5.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		button_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try {
					String sql = "Delete from customer where Customer_ID =?";
					conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/finalproject","root","admin");
					stat = conn.prepareStatement(sql);
					stat.setString(1,CustomerID.getText());
					stat.executeUpdate();
					
				
				JOptionPane.showMessageDialog(null, "Customer Deleted");
				
				}
				catch(SQLException	| HeadlessException ex) {
				
					JOptionPane.showMessageDialog(null, ex);
			
				}

				cinfo Frame1 = new cinfo();	
				Frame1.table();
				Frame1.setVisible(true);
				
				dispose();
				
			}
		});
		button_5.setBounds(476, 336, 115, 27);
		contentPane.add(button_5);
		
		JButton btnEmployees = new JButton("Employees");
		btnEmployees.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		btnEmployees.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Employee frame = new Employee();
				frame.table();
				frame.setVisible(true);
				dispose();
			}
		});
		btnEmployees.setForeground(Color.WHITE);
		btnEmployees.setBackground(new Color(0, 153, 255));
		btnEmployees.setBounds(0, 99, 148, 51);
		contentPane.add(btnEmployees);
		
		JButton btnOrders = new JButton("Orders");
		btnOrders.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		btnOrders.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Order frame = new Order();
				frame.table();
				frame.setVisible(true);
				dispose();
			}
		});
		btnOrders.setForeground(Color.WHITE);
		btnOrders.setBackground(new Color(0, 153, 255));
		btnOrders.setBounds(0, 201, 148, 51);
		contentPane.add(btnOrders);
		
		JLabel label = new JLabel("Grocery Inventory Management System");
		label.setFont(new Font("Microsoft JhengHei UI", Font.BOLD, 20));
		label.setBounds(246, 43, 385, 27);
		contentPane.add(label);
		
		JLabel label_2 = new JLabel("Back");
		label_2.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		label_2.setBounds(629, 341, 40, 18);
		contentPane.add(label_2);
		
		JButton button_6 = new JButton("");
		button_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cinfo frame = new cinfo();
				frame.table();
				frame.setVisible(true);
				dispose();
			}
		});
		button_6.setIcon(new ImageIcon("C:\\Users\\Owner1\\Downloads\\iconfinder_basics-01_296833 (2).png"));
		button_6.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		button_6.setBounds(673, 337, 30, 27);
		contentPane.add(button_6);
	}
}
