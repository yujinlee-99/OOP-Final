package yujin;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.HeadlessException;

import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;

public class EditSupplier extends JFrame {

	private JPanel contentPane;
	private JTextField supplierID;
	private JTextField SupplierName;
	private JTextField CN;
	private JTextField SupplierID;

	Connection conn = null;
	PreparedStatement stat = null;
	ResultSet rs = null;
	private JTextField pid;
	
	
	/**
	 * Launch the application.
	 
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					EditSupplier frame = new EditSupplier();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	*/
	/**
	 * Create the frame.
	 */
	public EditSupplier() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 760, 450);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 255, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton button = new JButton("Products");
		button.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Product frame = new Product();
				frame.table();
				frame.setVisible(true);
				dispose();
			}
		});
		button.setForeground(Color.WHITE);
		button.setBackground(new Color(0, 153, 255));
		button.setBounds(0, 47, 148, 51);
		contentPane.add(button);
		
		JButton button_1 = new JButton("Customers");
		button_1.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cinfo frame = new cinfo();
				frame.table();
				frame.setVisible(true);
				dispose();
			}
		});
		button_1.setForeground(Color.WHITE);
		button_1.setBackground(new Color(0, 153, 255));
		button_1.setBounds(0, 149, 148, 51);
		contentPane.add(button_1);
		
		JButton button_2 = new JButton("Delivery");
		button_2.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dinfo frame = new dinfo();
				frame.table();
				frame.setVisible(true);
				dispose();
			}
		});
		button_2.setForeground(Color.WHITE);
		button_2.setBackground(new Color(0, 153, 255));
		button_2.setBounds(0, 250, 148, 51);
		contentPane.add(button_2);
		
		JButton button_3 = new JButton("Supplier");
		button_3.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		button_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				sinfo frame = new sinfo();
				frame.table();
				frame.setVisible(true);
				dispose();
			}
		});
		button_3.setForeground(Color.WHITE);
		button_3.setBackground(new Color(135, 206, 250));
		button_3.setBounds(0, 301, 148, 51);
		contentPane.add(button_3);
		
		JLabel lblNewLabel = new JLabel("Supplier ID");
		lblNewLabel.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		lblNewLabel.setBounds(209, 108, 103, 18);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Supplier Name");
		lblNewLabel_1.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		lblNewLabel_1.setBounds(209, 153, 115, 18);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Contact Number");
		lblNewLabel_2.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		lblNewLabel_2.setBounds(209, 202, 115, 18);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Supplier ID");
		lblNewLabel_3.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		lblNewLabel_3.setBounds(209, 329, 103, 18);
		contentPane.add(lblNewLabel_3);
		
		supplierID = new JTextField();
		supplierID.setText("");
		supplierID.setBounds(342, 105, 116, 24);
		contentPane.add(supplierID);
		supplierID.setColumns(10);
		
		SupplierName = new JTextField();
		SupplierName.setBounds(342, 150, 116, 24);
		contentPane.add(SupplierName);
		SupplierName.setColumns(10);
		
		CN = new JTextField();
		CN.setBounds(342, 199, 116, 24);
		contentPane.add(CN);
		CN.setColumns(10);
		
		SupplierID = new JTextField();
		SupplierID.setBounds(342, 326, 116, 24);
		contentPane.add(SupplierID);
		SupplierID.setColumns(10);
		
		JButton button_4 = new JButton("Add");
		button_4.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		button_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try {
					
					String sql = "Insert into supplier" + "(Supplier_ID, Supplier_Name, Supplier_CN, Product_ID)" + "values (?,?,?,?)";
					conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/finalproject?useTimezone=true&serverTimezone=UTC", "root", "admin");
					stat = conn.prepareStatement(sql);
					stat.setString(1, supplierID.getText());
					stat.setString(2, SupplierName.getText());
					stat.setString(3, CN.getText());
					stat.setString(4, pid.getText());
					stat.executeUpdate();
					JOptionPane.showMessageDialog(null, "Supplier info Added");
					sinfo Frame1 = new sinfo();
					Frame1.table();
					Frame1.setVisible(true);
					
					dispose();
					
					
				} 
					
					catch(SQLException | HeadlessException ex) {
					JOptionPane.showMessageDialog(null, ex);
				}
				
			}
		});
		button_4.setBounds(490, 245, 115, 27);
		contentPane.add(button_4);
		
		JButton button_5 = new JButton("Delete");
		button_5.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		button_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try {
					String sql = "Delete from supplier where Supplier_ID =?";
				conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/finalproject","root","admin");
					stat = conn.prepareStatement(sql);
					stat.setString(1,SupplierID.getText());
					stat.executeUpdate();
					
				
				JOptionPane.showMessageDialog(null, "Supplier info Deleted");
				
				}
				catch(SQLException	| HeadlessException ex) {
				
					JOptionPane.showMessageDialog(null, ex);
			
				}

				sinfo Frame1 = new sinfo();	
				Frame1.table();
				Frame1.setVisible(true);
				
				dispose();
				
			}
		});
		button_5.setBounds(490, 325, 115, 27);
		contentPane.add(button_5);
		
		JButton btnEmployees = new JButton("Employees");
		btnEmployees.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		btnEmployees.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Employee frame = new Employee();
				frame.table();
				frame.setVisible(true);
				dispose();
			}
		});
		btnEmployees.setForeground(Color.WHITE);
		btnEmployees.setBackground(new Color(0, 153, 255));
		btnEmployees.setBounds(0, 98, 148, 51);
		contentPane.add(btnEmployees);
		
		JButton btnOrders = new JButton("Orders");
		btnOrders.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		btnOrders.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Order frame = new Order();
				frame.table();
				frame.setVisible(true);
				dispose();
			}
		});
		btnOrders.setForeground(Color.WHITE);
		btnOrders.setBackground(new Color(0, 153, 255));
		btnOrders.setBounds(0, 199, 148, 51);
		contentPane.add(btnOrders);
		
		JLabel lblNewLabel_4 = new JLabel("Product ID");
		lblNewLabel_4.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		lblNewLabel_4.setBounds(209, 249, 103, 18);
		contentPane.add(lblNewLabel_4);
		
		pid = new JTextField();
		pid.setText("");
		pid.setBounds(342, 246, 116, 24);
		contentPane.add(pid);
		pid.setColumns(10);
		
		JLabel label = new JLabel("Grocery Inventory Management System");
		label.setFont(new Font("Microsoft JhengHei UI", Font.BOLD, 20));
		label.setBounds(243, 43, 385, 27);
		contentPane.add(label);
		
		JLabel label_1 = new JLabel("Back");
		label_1.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		label_1.setBounds(631, 329, 40, 18);
		contentPane.add(label_1);
		
		JButton button_6 = new JButton("");
		button_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				sinfo frame = new sinfo();
				frame.table();
				frame.setVisible(true);
				dispose();
			}
		});
		button_6.setIcon(new ImageIcon("C:\\Users\\Owner1\\Downloads\\iconfinder_basics-01_296833 (2).png"));
		button_6.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		button_6.setBounds(675, 325, 30, 27);
		contentPane.add(button_6);
	}

}
